#include "pch.h"
#include "_rift.h"

BOOL fnCreateRegEntry() {

}

BOOL fnDeleteRegEntry() {

}

