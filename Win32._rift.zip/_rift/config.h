#ifndef _config_HIG
#define _config_HIG

/* Xoshiro */
#define _DISABLE_JUMPS 0

#endif // !_config_HIG