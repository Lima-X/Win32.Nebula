#ifndef _PCH_HIG
#define _PCH_HIG

#include <Windows.h>

#endif //_PCH_HIG